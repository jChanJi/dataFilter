
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class ParseXml {
	private static Document document;
	private static SAXReader reader;
	// 获取根节点元素对象
	private static Element root;// 查找根节点名
	private static StringBuffer info = new StringBuffer();// 存储商品 信息一
	private static String FILEPATH = "F:/data/服装/jack/";
	private static String URL;
	public ParseXml() throws DocumentException {

	}

	public static void main(String[] args) throws Exception {
		
		readfile_one("F:/test");
		write_csv_one("F:/data/服装/indexTable/");
		System.out.println("info:" + "\n" + info);
	}

	public static boolean readfile_one(String filepath) throws FileNotFoundException, IOException, DocumentException {
		try {
			File file = new File(filepath);
			if (!file.isDirectory()) {
			//	System.out.println("文件");
				//System.out.println("name=" + file.getName());
			} else if (file.isDirectory() && !(file.getName().equals(".meta"))) {
				//System.out.println("文件夹:" + file.getName());
				String[] filelist = file.list();
				for (int i = 0; i < filelist.length; i++) {
					File readfile = new File(filepath + "\\" + filelist[i]);
					if (!readfile.isDirectory()) {
						String dir_name = readfile.getParentFile().getName(); 
						//System.out.println("sss:"+dir_name);
						reader = new SAXReader();
						document = reader.read(readfile);
						//System.out.println(readfile.getName());
						if (i < 1) {
							geturl("realpath");
							ruleone("规则_1");
							ruletwo("规则_2");
						}
						rulethree("规则_3",FILEPATH,dir_name);
					
					} else if (file.isDirectory() && !(file.getName().equals(".meta"))) {
						readfile_one(filepath + "\\" + filelist[i]);
					}
					
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println("readfile()   Exception:" + e.getMessage());
		}
		return true;
	}

	// 获取商品地址
	public static void geturl(String nodeName) {
		root = document.getRootElement();
		Element e = root.element(nodeName);
		System.out.println("=================网址：" + e.getName() + "=================");
		String url = e.getStringValue();
		URL = url;
		info.append(url);
		info.append(",");
	}

	// 获取规则一内容（评论数量、销量、品牌名称）,nodeName="规则_1"
	@SuppressWarnings("unchecked")
	public static void ruleone(String nodeName) {
		root = document.getRootElement();
		List<Element> childList = root.elements(nodeName);
		System.out.println("=================一级元素名称" + ":" + nodeName + "=================");
		for (Element e : childList) {
			List<Element> elements = e.elements();
			for (Element e2 : elements) {
				List<Element> elements2 = e2.elements();
				for (int i = 0; i < elements2.size(); i++) {
					if (i < 2) {
						String str = elements2.get(i).getStringValue();// 待过滤的字符串
						str = str.replaceAll("[\u4e00-\u9fa5]+", "");
						info.append(str + ",");
					} else {
						String goodname = elements2.get(i).getStringValue();
						info.append(goodname + ",");
					}

				}
			}
		}

	}

	// 获取规则_2内容（品牌）
	@SuppressWarnings("unchecked")
	public static void ruletwo(String nodeName) {
		root = document.getRootElement();
		List<Element> childList = root.elements(nodeName);
		System.out.println("=================一级元素名称" + ":" + nodeName + "=================");
		for (Element e : childList) {
			List<Element> elements = e.elements();
			for (Element e2 : elements) {
				List<Element> elements2 = e2.elements();
				for (Element e3 : elements2) {
					String str = e3.getStringValue();// 待过滤的字符串
					str = str.split(":")[1].substring(1);
					info.append(str);
					info.append("\n");
				}
			}
		}
	}

	// 获取规则_3内容（评论、评论时间、尺码、颜色）
	@SuppressWarnings("unchecked")
	public static void rulethree(String nodeName,String filepath,String dir_name ) throws IOException {
		root = document.getRootElement();
		List<Element> childList = root.elements(nodeName);
		System.out.println("=================一级元素名称" + ":" + nodeName + "=================");
		for (Element e : childList) {
			List<Element> elements = e.elements();
			for (Element e2 : elements) {
				List<Element> elements2 = e2.elements();
				StringBuffer sb = new StringBuffer();
				for (int i = 0; i < elements2.size(); i++ ) {
					String str = elements2.get(i).getStringValue();
					String[] strs = null;
					if(i==0){
						strs = str.split("：");
						String color = strs[1].replaceAll("色","色:").split(":")[0];
						String size = strs[2];
						sb.append(color+","+size+",");
						//System.out.println(color+":"+size);
					}else if(i==1){
						String time = str;
						sb.append(time+",");
					//	System.out.println(time);
					}else if(i==2){
						String comment = str;
						sb.append(comment+",");
						sb.append("\n");
						//System.out.println(comment);
					}
					//System.out.println("三级元素值:" + elements2.get(i).getStringValue());
				}
				//System.out.println(sb);
				write_csv_two(filepath,dir_name,sb);
				
			}
		}

	}

	// 将商品信息一写入csv文件
	@SuppressWarnings("unused")
	private static void write_csv_one(String filepath) throws IOException {
		File file = new File(filepath + "/test.csv");
		
		if(!(file.getParentFile().exists())){
			if(!file.getParentFile().mkdirs()){
				System.out.println("创建文件失败");
			}
				file.createNewFile();
				FileOutputStream fo = new FileOutputStream(file, true);
				OutputStreamWriter ow = new OutputStreamWriter(fo);
				BufferedWriter bw = new BufferedWriter(ow);
				bw.write("url,comment_num,sale_num_month,name,brand" + "\n");
				bw.close();
		}
		FileOutputStream fo = new FileOutputStream(file, true);
		OutputStreamWriter ow = new OutputStreamWriter(fo);
		BufferedWriter bw = new BufferedWriter(ow);
		bw.write(info.toString());
		bw.close();
	}
	// 将商品信息一写入csv文件
		@SuppressWarnings("unused")
		private static void write_csv_two(String filepath,String dir_name,StringBuffer sb) throws IOException {
			File file = new File(filepath + dir_name +"/test2.csv");
			System.out.println(file.getAbsolutePath());
			if(!(file.getParentFile().exists())){
				if(!file.getParentFile().mkdirs()){
					System.out.println("创建文件失败");
				}
					file.createNewFile();
					FileOutputStream fo = new FileOutputStream(file, true);
					OutputStreamWriter ow = new OutputStreamWriter(fo);
					BufferedWriter bw = new BufferedWriter(ow);
					bw.write("color,size,time,comment,url,"+URL+"\n");
					bw.close();
			}
			FileOutputStream fo = new FileOutputStream(file, true);
			OutputStreamWriter ow = new OutputStreamWriter(fo);
			BufferedWriter bw = new BufferedWriter(ow);
			bw.write(sb.toString());
			bw.close();
			
		}

}
